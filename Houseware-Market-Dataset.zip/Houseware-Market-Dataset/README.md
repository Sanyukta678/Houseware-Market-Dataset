# Houseware Market Dataset (RC3620)

**Dataset name:** Houseware Market Dataset  
**Source / Report:** Next Move Strategy Consulting — *Houseware Market (RC3620)*  
**Created on:** 2025-12-04

---

## Overview

This repository contains a companion dataset created to support research and analysis of the global **Houseware Market** (report code RC3620).  
The files are provided as a starting point — they contain structured fields and **placeholder/sample** entries you can replace with the actual data extracted from the report or other verified sources.

**Purpose:**  
- Provide a reproducible folder structure and metadata layout for market datasets.  
- Help analysts quickly transform report content into CSV/JSON artifacts suitable for visualization, model input, or inclusion in blog posts.

---

## Contents

- `data/houseware_market_data.csv` — tabular dataset (sample rows).  
- `data/metadata.json` — machine-readable metadata describing fields and provenance.  
- `report_summary.txt` — short, neutral summary / notes about the report and dataset.  
- `README.md` — this file.  
- `LICENSE` — MIT license.  

---

## Sample fields (in `houseware_market_data.csv`)

- `id` — unique row id  
- `year` — year of observation (YYYY)  
- `region` — geographic region (e.g., North America, Europe)  
- `segment` — product segment (e.g., Cookware, Tableware, Kitchen Storage)  
- `company` — company or vendor name (if applicable)  
- `metric` — metric type (e.g., Market Size, CAGR, Revenue)  
- `value` — numeric value (units described in `metadata.json`)  
- `unit` — unit of the value (e.g., USD Million, %)  
- `source` — original source or note  

> ⚠️ **Important:** The current CSV contains placeholder/sample rows only. Replace with validated values from the Next Move Strategy Consulting report (RC3620) or other primary sources before publishing or citing.

---

## How to use

1. Download and unzip the dataset.  
2. Replace sample rows in `data/houseware_market_data.csv` with actual extracted values.  
3. Update `data/metadata.json` to reflect correct units, currency, and provenance.  
4. Keep the `report_summary.txt` as working notes or update it to include key report takeaways, methodology, and page references.

---

## Citation

If you use this dataset in analysis or a publication, please cite the original report:

> Next Move Strategy Consulting. *Houseware Market (RC3620).* [https://www.nextmsc.com/report/houseware-market-rc3620](https://www.nextmsc.com/report/houseware-market-rc3620)

And optionally cite this dataset repository.

---

## License

This repository is released under the MIT License — see `LICENSE` for details.

---

## Contact

For questions or corrections, open an issue or contact the dataset maintainer.

